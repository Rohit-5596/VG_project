import { Injectable } from '@angular/core';
import { Investment } from '../models/investment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Login } from '../models/login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  url: string = '../assets/utility/loginDetails.json';
  status: string;
  loginService : Login;
  
  constructor(private http: HttpClient) { }

  getData(): Observable<Login> {
    return this.http.get<Login>(this.url);
  }
}
