import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Investment } from './models/investment';
import { DashboardService } from './Services/dashboard.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'VanInvAdvApp';
  //constructor (private httpService: HttpClient) { }
  //arrInvest: Investment [];

  /*ngOnInit () {
    this.httpService.get('./assets/utility/investorDetails.json').subscribe(
      data => {
        this.arrInvest = data as Investment [];	 
          console.log(this.arrInvest[0]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  
    //this.arrInvest= this.dashService.getAllInvestors();
    }*/

}
