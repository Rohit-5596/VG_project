export class Investment {

    investmentId: String;
    pwd: String;
    income: number;
    expenses: number;
    lifeExpectancy: number;

    /*constructor( investmentId: String, pwd:String, income:number , expenses:number, lifeExpectancy:number){
        this.investmentId=investmentId;
        this.pwd=pwd;
        this.income=income;
        this.expenses=expenses;
        this.lifeExpectancy=lifeExpectancy;*/

    }

