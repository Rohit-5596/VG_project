export class Login {

    investmentId: String;
    password: String;
}
