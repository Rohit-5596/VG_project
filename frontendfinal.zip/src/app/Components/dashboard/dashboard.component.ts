import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/Services/dashboard.service';
import { Investment } from 'src/app/models/investment';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  arrInvest: Investment [];
  constructor(private dashService: DashboardService ) { }

  ngOnInit() {
    this.dashService.getData().subscribe(data => {this.arrInvest = data; console.log(data)});
    console.log(this.arrInvest + 'here');

  }
  status(i: number) {
    if (confirm('The current status is "painful"')) {
      this.dashService.statusCheck(i);
    }

  }
}
