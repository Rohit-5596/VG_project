import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { LogoutComponent } from '../logout/logout.component';
import { LoginService } from 'src/app/Services/login.service';
import { Login } from 'src/app/models/login';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

 
  log: Login = {investmentId : '', password: ''};
  userName: string;
  password: string;
  

  constructor(private router: Router,private loginService: LoginService) { }

  ngOnInit() {

    
    this.loginService.getData().subscribe(data => {this.log = data; console.log(data)});
    console.log(this.log + 'here');
    
  }

  login(){
    if(this.log.investmentId === "b001" && this.log.password === "john")
    alert('logged in successfully');
      this.router.navigate(['dashboard']);
    
  }

  

}
