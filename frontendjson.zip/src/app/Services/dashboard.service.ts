import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Investment } from '../models/investment';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  investService : Investment

  constructor() { }
}
